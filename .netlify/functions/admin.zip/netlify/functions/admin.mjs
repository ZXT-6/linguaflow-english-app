
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin.mjs
import { getStore as getStore2 } from "@netlify/blobs";

// netlify/functions/_shared/auth-store.mjs
import { randomBytes, createHash } from "node:crypto";
import { getStore } from "@netlify/blobs";
var USER_STORE = "linguaflow-users";
var SESSION_STORE = "linguaflow-sessions";
function json(data, init = {}) {
  return Response.json(data, {
    ...init,
    headers: {
      "Cache-Control": "no-store",
      ...init.headers || {}
    }
  });
}
function hashValue(value) {
  return createHash("sha256").update(String(value)).digest("hex");
}
function publicUser(user) {
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role || "learner",
    createdAt: user.createdAt
  };
}
async function usersStore() {
  return getStore({ name: USER_STORE, consistency: "strong" });
}
async function sessionsStore() {
  return getStore({ name: SESSION_STORE, consistency: "strong" });
}
async function userFromRequest(request) {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.startsWith("Bearer ") ? authorization.slice(7).trim() : "";
  if (!token) {
    return null;
  }
  const session = await (await sessionsStore()).get(`tokens/${hashValue(token)}.json`, { type: "json" });
  if (!session?.userId) {
    return null;
  }
  return (await usersStore()).get(`users/${session.userId}.json`, { type: "json" });
}

// netlify/functions/admin.mjs
async function readLearningSummary(userId) {
  const store = getStore2({ name: "learning-state", consistency: "strong" });
  const state = await store.get(`users/${userId}/state.json`, { type: "json" });
  return {
    hasState: Boolean(state),
    minutes: Number(state?.minutes || 0),
    wordsLearned: Number(state?.wordsLearned || 0),
    streak: Number(state?.streak || 0),
    updatedAt: state?.sync?.lastSyncedAt || state?.updatedAt || null
  };
}
async function listUsers() {
  const store = await usersStore();
  const { blobs } = await store.list({ prefix: "users/" });
  const users = await Promise.all(
    blobs.filter((blob) => blob.key.endsWith(".json")).map(async (blob) => store.get(blob.key, { type: "json" }))
  );
  const visibleUsers = users.filter((user) => user?.id);
  const rows = await Promise.all(
    visibleUsers.map(async (user) => ({
      ...publicUser(user),
      ...await readLearningSummary(user.id)
    }))
  );
  return rows.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
}
async function handler(request) {
  if (request.method !== "GET") {
    return json({ error: "Method not allowed" }, { status: 405 });
  }
  const user = await userFromRequest(request);
  if (!user?.id) {
    return json({ error: "Unauthorized" }, { status: 401 });
  }
  if (user.role !== "admin") {
    return json({ error: "Forbidden" }, { status: 403 });
  }
  const users = await listUsers();
  return json({ users });
}
var config = {
  path: "/api/admin/users"
};
export {
  config,
  handler as default
};
