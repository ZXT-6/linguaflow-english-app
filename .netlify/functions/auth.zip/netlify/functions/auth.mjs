
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth.mjs
import { randomUUID } from "node:crypto";

// netlify/functions/_shared/auth-store.mjs
import { randomBytes, createHash } from "node:crypto";
import { getStore } from "@netlify/blobs";
var USER_STORE = "linguaflow-users";
var SESSION_STORE = "linguaflow-sessions";
function json(data, init = {}) {
  return Response.json(data, {
    ...init,
    headers: {
      "Cache-Control": "no-store",
      ...init.headers || {}
    }
  });
}
function normalizeIdentifier(value) {
  return String(value || "").trim().toLowerCase();
}
function hashValue(value) {
  return createHash("sha256").update(String(value)).digest("hex");
}
function createPasswordHash(password, salt = randomBytes(16).toString("hex")) {
  return {
    salt,
    hash: hashValue(`${salt}:${password}`)
  };
}
function verifyPassword(password, passwordRecord = {}) {
  if (!passwordRecord.salt || !passwordRecord.hash) {
    return false;
  }
  return createPasswordHash(password, passwordRecord.salt).hash === passwordRecord.hash;
}
function publicUser(user) {
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role || "learner",
    createdAt: user.createdAt
  };
}
async function usersStore() {
  return getStore({ name: USER_STORE, consistency: "strong" });
}
async function sessionsStore() {
  return getStore({ name: SESSION_STORE, consistency: "strong" });
}
async function getUserByIdentifier(identifier) {
  const store = await usersStore();
  const key = normalizeIdentifier(identifier);
  if (!key) {
    return null;
  }
  const index = await store.get(`indexes/${key}.json`, { type: "json" });
  if (!index?.userId) {
    return null;
  }
  return store.get(`users/${index.userId}.json`, { type: "json" });
}
async function saveUser(user) {
  const store = await usersStore();
  await store.setJSON(`users/${user.id}.json`, user);
  await store.setJSON(`indexes/${normalizeIdentifier(user.username)}.json`, { userId: user.id });
  await store.setJSON(`indexes/${normalizeIdentifier(user.email)}.json`, { userId: user.id });
}
async function createSession(userId) {
  const token = randomBytes(32).toString("hex");
  const tokenHash = hashValue(token);
  const store = await sessionsStore();
  await store.setJSON(`tokens/${tokenHash}.json`, {
    userId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  return token;
}

// netlify/functions/auth.mjs
function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || ""));
}
async function readBody(request) {
  return request.json().catch(() => ({}));
}
async function handleRegister(request) {
  const body = await readBody(request);
  const username = String(body.username || "").trim();
  const email = normalizeIdentifier(body.email);
  const password = String(body.password || "");
  if (username.length < 2 || !validEmail(email) || password.length < 6) {
    return json({ error: "\u8BF7\u586B\u5199\u7528\u6237\u540D\u3001\u6709\u6548\u90AE\u7BB1\u548C\u81F3\u5C11 6 \u4F4D\u5BC6\u7801\u3002" }, { status: 400 });
  }
  if (await getUserByIdentifier(username) || await getUserByIdentifier(email)) {
    return json({ error: "\u8FD9\u4E2A\u8D26\u53F7\u5DF2\u7ECF\u6CE8\u518C\u8FC7\uFF0C\u8BF7\u76F4\u63A5\u767B\u5F55\u3002" }, { status: 409 });
  }
  const user = {
    id: randomUUID(),
    username,
    email,
    role: username.toLowerCase().includes("admin") ? "admin" : "learner",
    password: createPasswordHash(password),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await saveUser(user);
  const token = await createSession(user.id);
  return json({ token, user: publicUser(user) });
}
async function handleLogin(request) {
  const body = await readBody(request);
  const identifier = body.email || body.username;
  const password = String(body.password || "");
  const user = await getUserByIdentifier(identifier);
  if (!user || !verifyPassword(password, user.password)) {
    return json({ error: "\u8D26\u53F7\u6216\u5BC6\u7801\u4E0D\u6B63\u786E\u3002" }, { status: 401 });
  }
  const token = await createSession(user.id);
  return json({ token, user: publicUser(user) });
}
async function handler(request) {
  if (request.method !== "POST") {
    return json({ error: "Method not allowed" }, { status: 405 });
  }
  const url = new URL(request.url);
  if (url.pathname.endsWith("/register")) {
    return handleRegister(request);
  }
  if (url.pathname.endsWith("/login")) {
    return handleLogin(request);
  }
  return json({ error: "Not found" }, { status: 404 });
}
var config = {
  path: ["/api/auth/register", "/api/auth/login"]
};
export {
  config,
  handler as default
};
