
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/learning-state.mjs
import { getStore as getStore2 } from "@netlify/blobs";

// netlify/functions/_shared/auth-store.mjs
import { randomBytes, createHash } from "node:crypto";
import { getStore } from "@netlify/blobs";
var USER_STORE = "linguaflow-users";
var SESSION_STORE = "linguaflow-sessions";
function json(data, init = {}) {
  return Response.json(data, {
    ...init,
    headers: {
      "Cache-Control": "no-store",
      ...init.headers || {}
    }
  });
}
function hashValue(value) {
  return createHash("sha256").update(String(value)).digest("hex");
}
async function usersStore() {
  return getStore({ name: USER_STORE, consistency: "strong" });
}
async function sessionsStore() {
  return getStore({ name: SESSION_STORE, consistency: "strong" });
}
async function userFromRequest(request) {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.startsWith("Bearer ") ? authorization.slice(7).trim() : "";
  if (!token) {
    return null;
  }
  const session = await (await sessionsStore()).get(`tokens/${hashValue(token)}.json`, { type: "json" });
  if (!session?.userId) {
    return null;
  }
  return (await usersStore()).get(`users/${session.userId}.json`, { type: "json" });
}

// netlify/functions/learning-state.mjs
async function handler(request) {
  const user = await userFromRequest(request);
  if (!user?.id) {
    return json({ error: "Unauthorized" }, { status: 401 });
  }
  const store = getStore2({ name: "learning-state", consistency: "strong" });
  const key = `users/${user.id}/state.json`;
  switch (request.method) {
    case "GET": {
      const state = await store.get(key, { type: "json" });
      return json({ state: state || null });
    }
    case "PUT": {
      const body = await request.json().catch(() => ({}));
      if (!body.state || typeof body.state !== "object") {
        return json({ error: "Missing state" }, { status: 400 });
      }
      await store.setJSON(key, body.state, {
        metadata: { updatedAt: (/* @__PURE__ */ new Date()).toISOString() }
      });
      return json({ state: body.state });
    }
    default:
      return json({ error: "Method not allowed" }, { status: 405 });
  }
}
var config = {
  path: "/api/learning-state"
};
export {
  config,
  handler as default
};
